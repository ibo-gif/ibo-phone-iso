# 🚀 IBO Phone ISO - НАЧНИ ОТСЮДА

Добро пожаловать в **IBO Phone ISO** - полнофункциональную мобильную операционную систему с встроенным магазином приложений и веб-браузером!

## 📱 Что это?

IBO Phone ISO это:
- ✓ **Полная ОС** на базе Linux для мобильных телефонов
- ✓ **App Store** встроен - магазин приложений
- ✓ **Браузер** встроен - для просмотра интернета
- ✓ **Поддержка APK и AAB** - все форматы приложений
- ✓ **Docker готов** - легко запустить в контейнере
- ✓ **2590 строк кода** - полностью функциональна

## 🎯 Три способа начать

### 1️⃣ Самый простой - Интерактивный инсталлятор

```bash
bash install.sh
```

Затем в меню выберите:
- `2` - Подготовить систему
- `3` - Построить ISO образ
- `8` - Информация о проекте

### 2️⃣ Вручную - Пошагово

```bash
# Шаг 1: Подготовка системы
bash build/setup-vm.sh

# Шаг 2: Сборка ISO образа
bash build/build.sh

# Результат: build_output/ibo-phone-1.0.0.iso
```

### 3️⃣ Docker - В контейнере

```bash
# Сборка Docker образа
docker build -f build/Dockerfile -t ibo-phone:latest .

# Запуск контейнера
docker run -it -v /workspaces/ibo-phone-iso:/ibo-phone-iso ibo-phone:latest
```

## 📚 Документация

| Файл | Что это |
|------|--------|
| [README.md](README.md) | Основное описание проекта |
| [SPECIFICATION.md](SPECIFICATION.md) | Полная техническая спецификация |
| [USAGE_GUIDE.md](USAGE_GUIDE.md) | Подробное руководство пользователя |
| [EXAMPLES.md](EXAMPLES.md) | Примеры кода и использования |
| [QUICK_SUMMARY.md](QUICK_SUMMARY.md) | Краткая сводка всего проекта |
| [PROJECT_STATS.txt](PROJECT_STATS.txt) | Статистика проекта |

## 🔧 Основные команды

### Установка приложений

```bash
# Установка APK (файл установки Android)
bash system/install_packages.sh install-apk myapp.apk com.example.app

# Установка AAB (современный формат)
bash system/install_packages.sh install-aab myapp.aab com.example.app

# Список установленных приложений
bash system/install_packages.sh list

# Удаление приложения
bash system/install_packages.sh uninstall com.example.app
```

## 💻 Структура проекта

```
ibo-phone-iso/
├── apps/                    # Исходные коды приложений
│   ├── ibo-appstore/       # Магазин приложений
│   └── ibo-browser/        # Веб-браузер
├── system/                 # Системные файлы
│   ├── boot.properties     # Параметры загрузки
│   ├── init.rc             # Скрипты инициализации
│   └── install_packages.sh # Инсталлятор пакетов
├── build/                  # Скрипты сборки
│   ├── build.sh           # Сборка ISO
│   └── setup-vm.sh        # Подготовка ВМ
├── packages/              # Репозиторий приложений
│   ├── apk/              # APK файлы
│   └── aab/              # AAB файлы
└── kernel/               # Конфигурация Linux kernel
```

## 🌟 Встроенные приложения

### IBO App Store
- Магазин приложений
- Установка приложений
- Управление приложениями
- Обновления

### IBO Browser
- Просмотр веб-сайтов
- Поддержка JavaScript
- История и закладки
- Управление кэшем

## 📋 Требования

| Параметр | Минимум | Рекомендуемо |
|----------|---------|-------------|
| Архитектура | ARM64 | ARM64 v8+ |
| Памяти | 1GB | 2GB |
| Хранилище | 8GB | 32GB |
| Kernel | 5.10 | 5.15+ |
| Java | Java 8 | Java 11+ |

## 🎓 Что вы узнаете

Проект демонстрирует:
- Разработку мобильной ОС
- Linux kernel конфигурацию
- Управление пакетами приложений
- Системы безопасности (SELinux)
- Java/Android программирование
- Bash scripting
- Docker контейнеризацию

## 🚀 Следующие шаги

### 1. Познакомиться с документацией
Прочитайте [README.md](README.md) для основного обзора

### 2. Подготовить систему
```bash
bash build/setup-vm.sh
```

### 3. Собрать ISO образ
```bash
bash build/build.sh
```

### 4. Установить приложение (опционально)
```bash
bash system/install_packages.sh install-apk myapp.apk com.example.app
```

### 5. Запустить на виртуальной машине
Используйте QEMU или VirtualBox для запуска ISO образа

## 🐳 Docker быстрый старт

```bash
# Сборка образа
docker build -f build/Dockerfile -t ibo-phone:latest .

# Запуск контейнера с интерактивным терминалом
docker run -it -v $(pwd):/ibo-phone-iso ibo-phone:latest

# Внутри контейнера - сборка ISO
bash build/build.sh
```

## 📝 Примеры

### Пример 1: Добавить собственное приложение

```bash
# 1. Скопировать APK в директорию пакетов
cp /path/to/myapp.apk packages/apk/

# 2. Использовать инсталлятор
bash system/install_packages.sh install-apk packages/apk/myapp.apk com.example.myapp

# 3. Проверить установку
bash system/install_packages.sh list
```

### Пример 2: Модифицировать браузер

```bash
# 1. Отредактировать исходный код
nano apps/ibo-browser/Browser.java

# 2. Перекомпилировать
javac -d build/output apps/ibo-browser/Browser.java

# 3. Собрать ISO
bash build/build.sh
```

## 🆘 Решение проблем

### Проблема: "Java не найден"
**Решение:** Установите Java
```bash
# Ubuntu/Debian
sudo apt-get install default-jdk

# macOS
brew install openjdk
```

### Проблема: "mkisofs не найден"
**Решение:** Установите ISO инструменты
```bash
# Ubuntu/Debian
sudo apt-get install cdrtools

# macOS
brew install cdrtools
```

### Проблема: "Недостаточно места"
**Решение:** Проверьте свободное место
```bash
df -h
rm -rf build_output/  # Очистить старые ISO
```

## 🎯 Статистика проекта

- **Всего файлов:** 22
- **Строк кода:** 2590
- **Размер:** ~150 KB
- **Языки:** Java, Bash, Markdown, XML
- **Документация:** 1500+ строк

## 🤝 Поддержка

Для получения помощи:
1. Прочитайте документацию (список выше)
2. Проверьте [USAGE_GUIDE.md](USAGE_GUIDE.md)
3. Посмотрите примеры в [EXAMPLES.md](EXAMPLES.md)
4. Проверьте логи: `/var/log/package_installer.log`

## 📄 Лицензия

```
IBO Phone ISO System © 2026
Все права защищены.
```

## 🎉 Готово!

Вы готовы начать работу с IBO Phone ISO!

**Выберите один из способов запуска:**

```bash
# Интерактивный инсталлятор (рекомендуется)
bash install.sh

# Или быстрые команды
bash build/setup-vm.sh && bash build/build.sh

# Или Docker
docker build -f build/Dockerfile -t ibo-phone:latest .
```

---

**Спасибо за выбор IBO Phone ISO! 🚀**

Если у вас есть вопросы, обратитесь к документации или проверьте примеры в проекте.
